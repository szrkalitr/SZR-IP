document.addEventListener('DOMContentLoaded', () => {
    let currentPage = 'dashboard';
    let historyPage = 0;
    const LIMIT = 20;

    // Sayfa geçişleri
    document.querySelectorAll('.nav-links a').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const page = link.dataset.page;
            switchPage(page);
        });
    });

    function switchPage(page) {
        document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
        document.querySelectorAll('.nav-links a').forEach(a => a.classList.remove('active'));
        document.getElementById(`page-${page}`).classList.add('active');
        document.querySelector(`[data-page="${page}"]`).classList.add('active');
        currentPage = page;
        if (page === 'dashboard') loadDashboard();
        if (page === 'history') loadHistory();
        if (page === 'stats') loadStats();
        if (page === 'settings') loadSettings();
    }

    // Dashboard
    async function loadDashboard() {
        const res = await fetch('/api/stats');
        const stats = await res.json();
        document.getElementById('d-total').textContent = stats.total;
        document.getElementById('d-avg').textContent = stats.avg_risk;
        document.getElementById('d-high').textContent = stats.high_risk;
        const recentRes = await fetch('/api/history?limit=5');
        const recent = await recentRes.json();
        const tbody = document.querySelector('#recent-table tbody');
        tbody.innerHTML = recent.map(r => `
            <tr>
                <td>${r.ip}</td>
                <td>${r.risk_score}</td>
                <td>${r.location?.country || '-'}</td>
                <td>${r.infrastructure?.isp || '-'}</td>
                <td>${new Date(r.timestamp).toLocaleString()}</td>
            </tr>
        `).join('');
    }

    // Analiz
    document.getElementById('analyze-btn').addEventListener('click', async () => {
        const ip = document.getElementById('ip-input').value.trim();
        if (!ip) return;
        const res = await fetch('/api/analyze', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ip})
        });
        const data = await res.json();
        renderAnalyzeResult(data);
    });

    function renderAnalyzeResult(data) {
        const container = document.getElementById('analyze-result');
        container.style.display = 'grid';
        if (data.error) {
            container.innerHTML = `<div class="result-card risk-high"><h4>Hata</h4><span>${data.message}</span></div>`;
            return;
        }
        const riskClass = data.risk_score >= 75 ? 'risk-high' : data.risk_score >= 35 ? 'risk-mid' : 'risk-low';
        container.innerHTML = `
            <div class="result-card ${riskClass}"><h4>IP</h4><span>${data.ip}</span></div>
            <div class="result-card ${riskClass}"><h4>Risk Skoru</h4><span>${data.risk_score}/100</span></div>
            <div class="result-card ${riskClass}"><h4>Güven</h4><span>${data.confidence}</span></div>
            <div class="result-card"><h4>Ülke / Şehir</h4><span>${data.location?.country || '-'} / ${data.location?.city || '-'}</span></div>
            <div class="result-card"><h4>ISP</h4><span>${data.infrastructure?.isp || '-'}</span></div>
            <div class="result-card"><h4>ASN</h4><span>${data.infrastructure?.asn || '-'}</span></div>
            <div class="result-card"><h4>Reverse DNS</h4><span>${data.rdns || '-'}</span></div>
            <div class="result-card"><h4>Koordinat Sapma</h4><span>${data.location?.sapma_km ? data.location.sapma_km + ' km' : '-'}</span></div>
            <div class="result-card"><h4>AbuseIPDB Skoru</h4><span>${data.intelligence?.abuseipdb?.abuse_score ?? '-'}</span></div>
            <div class="result-card"><h4>VirusTotal</h4><span>${data.intelligence?.virustotal?.malicious ?? 0} kötü</span></div>
            <div class="result-card"><h4>Shodan Portları</h4><span>${(data.intelligence?.shodan_ports || []).join(', ') || '-'}</span></div>
            <div class="result-card"><h4>Bayraklar</h4><span>${(data.infrastructure?.flags || []).join(', ') || '-'}</span></div>
            <div class="result-card"><h4>Aksiyon</h4><span>${data.recommended_action}</span></div>
        `;
    }

    // Geçmiş
    async function loadHistory(search = '') {
        const res = await fetch(`/api/history?limit=${LIMIT}&offset=${historyPage * LIMIT}&search=${search}`);
        const entries = await res.json();
        const tbody = document.querySelector('#history-table tbody');
        tbody.innerHTML = entries.map(e => `
            <tr>
                <td>${e.ip}</td>
                <td>${e.risk_score}</td>
                <td>${e.recommended_action}</td>
                <td>${e.location?.country || '-'}</td>
                <td>${new Date(e.timestamp).toLocaleString()}</td>
                <td><button onclick="viewHistoryDetail('${e.ip}')">Gör</button></td>
            </tr>
        `).join('');
        document.getElementById('history-page-info').textContent = historyPage + 1;
    }

    window.viewHistoryDetail = async (ip) => {
        const res = await fetch('/api/analyze', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ip})
        });
        const data = await res.json();
        renderAnalyzeResult(data);
        switchPage('analyze');
        document.getElementById('ip-input').value = ip;
    };

    document.getElementById('history-search-btn').addEventListener('click', () => {
        historyPage = 0;
        loadHistory(document.getElementById('history-search').value);
    });
    document.getElementById('history-prev').addEventListener('click', () => { if (historyPage > 0) { historyPage--; loadHistory(); }});
    document.getElementById('history-next').addEventListener('click', () => { historyPage++; loadHistory(); });

    // İstatistikler
    async function loadStats() {
        const res = await fetch('/api/stats');
        const stats = await res.json();
        drawRiskChart(stats.risk_distribution);
        drawCountryChart(stats.countries);
        drawIspChart(stats.isps);
    }

    let riskChart, countryChart, ispChart;
    function drawRiskChart(data) {
        const ctx = document.getElementById('riskChart').getContext('2d');
        if (riskChart) riskChart.destroy();
        riskChart = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: Object.keys(data),
                datasets: [{ data: Object.values(data), backgroundColor: ['#22c55e','#84cc16','#eab308','#f97316','#ef4444'] }]
            }
        });
    }
    function drawCountryChart(data) {
        const ctx = document.getElementById('countryChart').getContext('2d');
        if (countryChart) countryChart.destroy();
        countryChart = new Chart(ctx, {
            type: 'bar',
            data: { labels: Object.keys(data), datasets: [{ label: 'Analiz', data: Object.values(data), backgroundColor: '#3b82f6' }] }
        });
    }
    function drawIspChart(data) {
        const ctx = document.getElementById('ispChart').getContext('2d');
        if (ispChart) ispChart.destroy();
        ispChart = new Chart(ctx, {
            type: 'bar',
            data: { labels: Object.keys(data), datasets: [{ label: 'Analiz', data: Object.values(data), backgroundColor: '#8b5cf6' }] }
        });
    }

    // Ayarlar
    async function loadSettings() {
        const res = await fetch('/api/settings');
        const s = await res.json();
        document.getElementById('s-abuseipdb').value = s.abuseipdb_key || '';
        document.getElementById('s-virustotal').value = s.virustotal_key || '';
        document.getElementById('s-shodan').value = s.shodan_key || '';
        document.getElementById('s-slack').value = s.slack_webhook || '';
        document.getElementById('s-cache').value = s.cache_ttl;
        document.getElementById('s-block').value = s.risk_threshold_block;
        document.getElementById('s-verify').value = s.risk_threshold_verify;
        document.getElementById('s-concurrent').value = s.max_concurrent_requests;
    }

    document.getElementById('settings-form').addEventListener('submit', async (e) => {
        e.preventDefault();
        const data = {
            abuseipdb_key: document.getElementById('s-abuseipdb').value,
            virustotal_key: document.getElementById('s-virustotal').value,
            shodan_key: document.getElementById('s-shodan').value,
            slack_webhook: document.getElementById('s-slack').value,
            cache_ttl: parseInt(document.getElementById('s-cache').value),
            risk_threshold_block: parseInt(document.getElementById('s-block').value),
            risk_threshold_verify: parseInt(document.getElementById('s-verify').value),
            max_concurrent_requests: parseInt(document.getElementById('s-concurrent').value)
        };
        await fetch('/api/settings', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(data)
        });
        document.getElementById('settings-msg').textContent = 'Ayarlar kaydedildi.';
        setTimeout(() => { document.getElementById('settings-msg').textContent = ''; }, 2000);
    });

    // Başlangıç
    loadDashboard();
});