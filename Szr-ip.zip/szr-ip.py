#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import asyncio
import math
import socket
import sys
import json
import csv
import io
import argparse
import re
import subprocess
import os
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from datetime import datetime
import httpx
import aiodns
from aiohttp import web
import aiohttp_jinja2
import jinja2

try:
    import geoip2.database
    GEOIP2_AVAILABLE = True
except ImportError:
    GEOIP2_AVAILABLE = False

def haversine(coord1: Tuple[float, float], coord2: Tuple[float, float]) -> float:
    R = 6371.0
    lat1, lon1 = map(math.radians, coord1)
    lat2, lon2 = map(math.radians, coord2)
    dlat, dlon = lat2 - lat1, lon2 - lon1
    a = math.sin(dlat/2)**2 + math.cos(lat1)*math.cos(lat2)*math.sin(dlon/2)**2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))
    return R * c

def validate_ip(ip: str) -> bool:
    try:
        socket.inet_pton(socket.AF_INET, ip)
        return True
    except socket.error:
        try:
            socket.inet_pton(socket.AF_INET6, ip)
            return True
        except socket.error:
            return False

IP_REGEX = re.compile(r'\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b')

async def send_slack_alert(webhook_url: str, message: str):
    try:
        async with httpx.AsyncClient() as client:
            await client.post(webhook_url, json={"text": message}, timeout=5.0)
    except Exception as e:
        print(f"[!] Slack bildirimi gönderilemedi: {e}")

async def block_ip_firewall(ip: str):
    try:
        check = await asyncio.create_subprocess_exec(
            "iptables", "-C", "INPUT", "-s", ip, "-j", "DROP",
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
        )
        await check.wait()
        if check.returncode != 0:
            proc = await asyncio.create_subprocess_exec(
                "iptables", "-A", "INPUT", "-s", ip, "-j", "DROP"
            )
            await proc.wait()
            print(f"[+] IP engellendi (iptables): {ip}")
        else:
            print(f"[*] IP zaten engelli: {ip}")
    except Exception as e:
        print(f"[!] Firewall engelleme başarısız: {e}")

class Settings:
    def __init__(self, filepath="settings.json"):
        self.filepath = filepath
        self.data = {
            "abuseipdb_key": "",
            "virustotal_key": "",
            "shodan_key": "",
            "slack_webhook": "",
            "cache_ttl": 3600,
            "risk_threshold_block": 75,
            "risk_threshold_verify": 35,
            "max_concurrent_requests": 5,
            "auto_block": False
        }
        self.load()

    def load(self):
        if os.path.exists(self.filepath):
            try:
                with open(self.filepath, "r") as f:
                    self.data.update(json.load(f))
            except:
                pass

    def save(self):
        with open(self.filepath, "w") as f:
            json.dump(self.data, f, indent=2)

    def get(self, key, default=None):
        return self.data.get(key, default)

    def set(self, key, value):
        self.data[key] = value
        self.save()

class IPIntelFusion:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.abuseipdb_key = settings.get("abuseipdb_key") or None
        self.virustotal_key = settings.get("virustotal_key") or None
        self.shodan_key = settings.get("shodan_key") or None
        self.local_blacklist = set()
        self.cache_ttl = settings.get("cache_ttl", 3600)
        self.semaphore = asyncio.Semaphore(settings.get("max_concurrent_requests", 5))
        self._cache: Dict[str, Dict] = {}
        self.city_reader = None
        self.asn_reader = None
        self.resolver = aiodns.DNSResolver()
        self._load_blacklist()
        self._init_maxmind()

    def _load_blacklist(self):
        path = "blacklist.json"
        if os.path.exists(path):
            try:
                with open(path) as f:
                    self.local_blacklist = set(json.load(f))
            except:
                pass

    def _init_maxmind(self):
        if GEOIP2_AVAILABLE:
            city_path = os.environ.get("MAXMIND_CITY", "GeoLite2-City.mmdb")
            asn_path = os.environ.get("MAXMIND_ASN", "GeoLite2-ASN.mmdb")
            if os.path.exists(city_path):
                try:
                    self.city_reader = geoip2.database.Reader(city_path)
                except:
                    pass
            if os.path.exists(asn_path):
                try:
                    self.asn_reader = geoip2.database.Reader(asn_path)
                except:
                    pass

    def update_keys(self):
        self.abuseipdb_key = self.settings.get("abuseipdb_key") or None
        self.virustotal_key = self.settings.get("virustotal_key") or None
        self.shodan_key = self.settings.get("shodan_key") or None
        self.cache_ttl = self.settings.get("cache_ttl", 3600)
        self.semaphore = asyncio.Semaphore(self.settings.get("max_concurrent_requests", 5))

    async def _async_reverse_dns(self, ip: str) -> str:
        try:
            parts = ip.split('.')
            if len(parts) == 4:
                reversed_ip = '.'.join(reversed(parts)) + '.in-addr.arpa'
                result = await self.resolver.query(reversed_ip, 'PTR')
                return result.name if result.name else "PTR Bulunamadı"
            return "PTR Çözümlemesi Atlattı (IPv6)"
        except Exception:
            return "PTR Kaydı Bulunamadı"

    async def _get_ipapi_com(self, client: httpx.AsyncClient, ip: str) -> Optional[Dict]:
        url = f"http://ip-api.com/json/{ip}?fields=status,country,regionName,city,lat,lon,isp,proxy,hosting,mobile"
        async with self.semaphore:
            try:
                resp = await client.get(url, timeout=4.0)
                if resp.status_code == 200:
                    data = resp.json()
                    if data.get("status") == "success":
                        return data
            except Exception:
                pass
        return None

    async def _get_ipapi_co(self, client: httpx.AsyncClient, ip: str) -> Optional[Dict]:
        async with self.semaphore:
            try:
                resp = await client.get(
                    f"https://ipapi.co/{ip}/json/",
                    headers={"User-Agent": "Mozilla/5.0"},
                    timeout=4.0
                )
                if resp.status_code == 200:
                    data = resp.json()
                    if "error" not in data:
                        return data
            except Exception:
                pass
        return None

    async def _get_abuseipdb(self, client: httpx.AsyncClient, ip: str) -> Dict:
        if not self.abuseipdb_key:
            return {"abuse_score": None, "total_reports": None, "last_reported": None}
        async with self.semaphore:
            try:
                headers = {"Key": self.abuseipdb_key, "Accept": "application/json"}
                params = {"ipAddress": ip, "maxAgeInDays": 90}
                resp = await client.get(
                    "https://api.abuseipdb.com/api/v2/check",
                    headers=headers, params=params, timeout=4.0
                )
                if resp.status_code == 200:
                    data = resp.json()["data"]
                    return {
                        "abuse_score": data.get("abuseConfidenceScore"),
                        "total_reports": data.get("totalReports"),
                        "last_reported": data.get("lastReportedAt")
                    }
            except Exception:
                pass
        return {"abuse_score": None, "total_reports": None, "last_reported": None}

    async def _get_virustotal(self, client: httpx.AsyncClient, ip: str) -> Dict:
        if not self.virustotal_key:
            return {"malicious": None, "suspicious": None, "harmless": None}
        async with self.semaphore:
            try:
                headers = {"x-apikey": self.virustotal_key}
                resp = await client.get(
                    f"https://www.virustotal.com/api/v3/ip_addresses/{ip}",
                    headers=headers, timeout=5.0
                )
                if resp.status_code == 200:
                    res_json = resp.json()
                    if "data" in res_json and "attributes" in res_json["data"]:
                        stats = res_json["data"]["attributes"]["last_analysis_stats"]
                        return {
                            "malicious": stats.get("malicious", 0),
                            "suspicious": stats.get("suspicious", 0),
                            "harmless": stats.get("harmless", 0)
                        }
            except Exception:
                pass
        return {"malicious": None, "suspicious": None, "harmless": None}

    async def _get_shodan(self, client: httpx.AsyncClient, ip: str) -> Dict:
        if not self.shodan_key:
            return {"ports": None, "org": None, "tags": None}
        async with self.semaphore:
            try:
                resp = await client.get(
                    f"https://api.shodan.io/shodan/host/{ip}?key={self.shodan_key}",
                    timeout=5.0
                )
                if resp.status_code == 200:
                    data = resp.json()
                    return {
                        "ports": data.get("ports", []),
                        "org": data.get("org", ""),
                        "tags": data.get("tags", [])
                    }
            except Exception:
                pass
        return {"ports": None, "org": None, "tags": None}

    def _maxmind_lookup(self, ip: str) -> Dict:
        result = {}
        if self.city_reader:
            try:
                response = self.city_reader.city(ip)
                result["city"] = response.city.name
                result["country"] = response.country.name
                result["lat"] = response.location.latitude
                result["lon"] = response.location.longitude
            except Exception:
                pass
        if self.asn_reader:
            try:
                response = self.asn_reader.asn(ip)
                result["asn"] = f"AS{response.autonomous_system_number}"
                result["asn_org"] = response.autonomous_system_organization
            except Exception:
                pass
        return result if result else None

    def _detect_infrastructure(self, a: Dict, b: Dict, shodan: Dict, maxmind: Dict) -> Dict:
        is_hosting = a.get("hosting", False) or "hosting" in (b.get("org") or "").lower()
        is_proxy = a.get("proxy", False)
        is_mobile = a.get("mobile", False)
        org = (b.get("org") or shodan.get("org") or "").lower()
        isp = (a.get("isp") or "").lower()

        flags = []
        if is_hosting or "datacenter" in org or "cloud" in org:
            flags.append("Veri Merkezi / Hosting")
        if is_mobile or "mobile" in org or "cellular" in isp:
            flags.append("Mobil Ağ (CGNAT)")
        if is_proxy or "vpn" in org or "proxy" in isp or "vpn" in isp:
            flags.append("Proxy/VPN Aktif")
        if "tor exit" in org or "tor-exit" in isp:
            flags.append("Tor Çıkış Düğümü (Kritik)")
        if "relay" in org or "icloud" in isp:
            flags.append("iCloud Private Relay / Anonim Çıkış")

        if shodan.get("tags"):
            shodan_tags = [t.lower() for t in shodan["tags"]]
            if "tor" in shodan_tags:
                flags.append("Tor (Shodan)")
            if "vpn" in shodan_tags:
                flags.append("VPN (Shodan)")

        asn_org = (maxmind.get("asn_org") or "").lower() if maxmind else ""
        if "google" in asn_org or "amazon" in asn_org or "microsoft" in asn_org:
            flags.append("Büyük Bulut Sağlayıcı")

        return {
            "hosting_flag": is_hosting,
            "proxy_flag": len([f for f in flags if "VPN" in f or "Tor" in f or "Anonim" in f]) > 0,
            "is_critical_tor": "Tor Çıkış Düğümü (Kritik)" in flags or "Tor (Shodan)" in flags,
            "asn": b.get("asn") or (maxmind.get("asn") if maxmind else "Bilinmiyor"),
            "org": b.get("org") or shodan.get("org") or (maxmind.get("asn_org") if maxmind else "Bilinmiyor"),
            "detected_flags": flags
        }

    def _calculate_risk_score(self, abuse_score: int, consistency: int,
                              infra: Dict, virustotal: Dict, shodan_ports: List) -> int:
        score = 0
        if abuse_score is not None:
            score += abuse_score * 0.5
        if consistency is not None:
            score += max(0, 100 - consistency) * 0.2
        if infra["hosting_flag"]:
            score += 15
        if infra["proxy_flag"]:
            score += 25
        if infra["is_critical_tor"]:
            score += 45
        if "Mobil Ağ (CGNAT)" in infra["detected_flags"]:
            score -= 5
        if virustotal and virustotal.get("malicious") is not None:
            total = virustotal["malicious"] + virustotal.get("suspicious", 0) + virustotal.get("harmless", 0)
            if total > 0:
                mal_ratio = virustotal["malicious"] / total
                score += mal_ratio * 40
        if shodan_ports is not None:
            if len(shodan_ports) > 10:
                score += 15
            elif len(shodan_ports) > 5:
                score += 8
        return min(100, max(0, int(score)))

    def _evaluate_consistency(self, a: Dict, b: Dict, distance: float) -> Tuple[int, List[str]]:
        score = 100
        notes = []
        penalty = min(50, int(distance // 10) * 5)
        score -= penalty
        if distance > 30:
            notes.append(f"Koordinat sapması yüksek ({distance:.1f} km)")
        city_a = (a.get("city") or "").strip().lower()
        city_b = (b.get("city") or "").strip().lower()
        if city_a and city_b and city_a != city_b:
            score -= 20
            notes.append("Veritabanları arasında şehir uyuşmazlığı")
        return max(0, score), notes

    async def analyze(self, client: httpx.AsyncClient, ip: str,
                      auto_block: bool = False, notify_webhook: Optional[str] = None) -> Dict:
        cached = self._cache.get(ip)
        if cached and (datetime.now() - cached["timestamp"]).seconds < self.cache_ttl:
            return cached["result"]

        if ip in self.local_blacklist:
            return {
                "ip": ip,
                "error": False,
                "summary": "Yerel kara listede",
                "risk_score": 100,
                "recommended_action": "block"
            }

        if not validate_ip(ip):
            return {"ip": ip, "error": True, "message": "Geçersiz IP adresi"}

        rdns_task = self._async_reverse_dns(ip)
        a_task = self._get_ipapi_com(client, ip)
        b_task = self._get_ipapi_co(client, ip)
        abuse_task = self._get_abuseipdb(client, ip)
        vt_task = self._get_virustotal(client, ip)
        shodan_task = self._get_shodan(client, ip)

        maxmind = self._maxmind_lookup(ip) if self.city_reader or self.asn_reader else None

        rdns, a, b, abuse, virustotal, shodan = await asyncio.gather(
            rdns_task, a_task, b_task, abuse_task, vt_task, shodan_task
        )

        if not a and not b and not maxmind:
            return {"ip": ip, "error": True, "message": "Hiçbir coğrafi kaynak çalışmadı"}

        lat_a, lon_a = (a.get("lat"), a.get("lon")) if a else (None, None)
        lat_b, lon_b = (b.get("latitude"), b.get("longitude")) if b else (None, None)
        lat_m, lon_m = (maxmind.get("lat"), maxmind.get("lon")) if maxmind else (None, None)

        distance = None
        if None not in (lat_a, lon_a, lat_b, lon_b):
            distance = haversine((lat_a, lon_a), (lat_b, lon_b))
        elif None not in (lat_a, lon_a, lat_m, lon_m) and lat_m:
            distance = haversine((lat_a, lon_a), (lat_m, lon_m))
        elif None not in (lat_b, lon_b, lat_m, lon_m) and lat_m:
            distance = haversine((lat_b, lon_b), (lat_m, lon_m))

        if a and b and distance is not None:
            consistency_score, notes = self._evaluate_consistency(a, b, distance)
        else:
            consistency_score = 60
            notes = ["Çapraz doğrulama için yeterli veri yok"]

        infra = self._detect_infrastructure(a or {}, b or {}, shodan, maxmind)
        abuse_score = abuse.get("abuse_score") or 0

        risk_score = self._calculate_risk_score(
            abuse_score, consistency_score, infra, virustotal,
            shodan.get("ports")
        )

        if distance and distance > 120:
            confidence = "Çok Düşük (Konum Şaşırtma)"
        elif infra["is_critical_tor"]:
            confidence = "Kritik (Aktif Tor)"
        elif risk_score >= 80:
            confidence = "Çok Düşük"
        elif risk_score >= 50:
            confidence = "Düşük"
        elif risk_score >= 30:
            confidence = "Orta"
        else:
            confidence = "Yüksek"

        threshold_block = self.settings.get("risk_threshold_block", 75)
        threshold_verify = self.settings.get("risk_threshold_verify", 35)

        if risk_score >= threshold_block:
            action = "block"
        elif risk_score >= threshold_verify:
            action = "verify"
        else:
            action = "allow"

        result = {
            "ip": ip,
            "rdns": rdns,
            "location": {
                "country": a.get("country") if a else (b.get("country_name") if b else (maxmind.get("country") if maxmind else None)),
                "region": a.get("regionName") if a else (b.get("region") if b else None),
                "city": a.get("city") if a else (b.get("city") if b else (maxmind.get("city") if maxmind else None)),
                "sapma_km": round(distance, 2) if distance else None
            },
            "infrastructure": {
                "isp": a.get("isp") if a else (b.get("org") if b else None),
                "asn": infra["asn"],
                "org": infra["org"],
                "flags": infra["detected_flags"]
            },
            "intelligence": {
                "abuseipdb": abuse,
                "virustotal": virustotal,
                "shodan_ports": shodan.get("ports"),
                "shodan_tags": shodan.get("tags"),
                "maxmind": maxmind
            },
            "risk_score": risk_score,
            "confidence": confidence,
            "recommended_action": action,
            "consistency_score": consistency_score,
            "consistency_notes": notes
        }

        self._cache[ip] = {"result": result, "timestamp": datetime.now()}

        if action == "block":
            message = (
                f"🚨 Yüksek Riskli IP: {ip} | Skor: {risk_score}/100 | "
                f"Konum: {result['location'].get('city')}, {result['location'].get('country')}"
            )
            if auto_block:
                await block_ip_firewall(ip)
                result["auto_blocked"] = True
            if notify_webhook:
                await send_slack_alert(notify_webhook, message)
                result["notified"] = True

        return result

    async def bulk_analyze(self, ip_list: List[str],
                           auto_block: bool = False,
                           notify_webhook: Optional[str] = None) -> List[Dict]:
        async with httpx.AsyncClient() as client:
            tasks = [self.analyze(client, ip, auto_block, notify_webhook) for ip in ip_list]
            return await asyncio.gather(*tasks)


class HistoryManager:
    def __init__(self, filepath="history.json"):
        self.filepath = filepath
        self.entries: List[Dict] = []
        self.load()

    def load(self):
        if os.path.exists(self.filepath):
            try:
                with open(self.filepath) as f:
                    self.entries = json.load(f)
            except:
                self.entries = []

    def save(self):
        with open(self.filepath, "w") as f:
            json.dump(self.entries[-1000:], f, indent=2)  # son 1000 kayıt

    def add(self, result: Dict):
        result["timestamp"] = datetime.now().isoformat()
        self.entries.append(result)
        self.save()

    def get_all(self, limit=50, offset=0, search=None) -> List[Dict]:
        filtered = self.entries
        if search:
            filtered = [e for e in filtered if search.lower() in e.get("ip", "").lower()]
        return filtered[::-1][offset:offset+limit]

    def stats(self) -> Dict:
        if not self.entries:
            return {"total": 0, "avg_risk": 0, "high_risk": 0, "countries": {}, "isps": {}}
        total = len(self.entries)
        risks = [e.get("risk_score", 0) for e in self.entries]
        avg_risk = sum(risks) / total
        high_risk = sum(1 for r in risks if r >= 75)
        countries = {}
        isps = {}
        for e in self.entries:
            loc = e.get("location", {})
            country = loc.get("country", "Bilinmiyor")
            isp = e.get("infrastructure", {}).get("isp", "Bilinmiyor")
            countries[country] = countries.get(country, 0) + 1
            isps[isp] = isps.get(isp, 0) + 1
        return {
            "total": total,
            "avg_risk": round(avg_risk, 1),
            "high_risk": high_risk,
            "countries": dict(sorted(countries.items(), key=lambda x: x[1], reverse=True)[:10]),
            "isps": dict(sorted(isps.items(), key=lambda x: x[1], reverse=True)[:10])
        }

    def risk_distribution(self) -> Dict[str, int]:
        ranges = {"0-20": 0, "21-40": 0, "41-60": 0, "61-80": 0, "81-100": 0}
        for e in self.entries:
            r = e.get("risk_score", 0)
            if r <= 20: ranges["0-20"] += 1
            elif r <= 40: ranges["21-40"] += 1
            elif r <= 60: ranges["41-60"] += 1
            elif r <= 80: ranges["61-80"] += 1
            else: ranges["81-100"] += 1
        return ranges


async def process_ip_safely(engine: IPIntelFusion, client: httpx.AsyncClient, ip: str,
                            auto_block: bool, notify_webhook: Optional[str]):
    try:
        result = await engine.analyze(client, ip, auto_block, notify_webhook)
        if result.get("recommended_action") == "block":
            print(f"[!] Şüpheli IP tespit edildi: {ip} (Risk Skoru: {result['risk_score']})")
            if result.get("auto_blocked"):
                print(f"    -> [Güvenlik] IP otomatik olarak iptables ile engellendi.")
            if result.get("notified"):
                print(f"    -> [Bildirim] Slack kanalına alarm gönderildi.")
    except Exception as e:
        print(f"[!] IP işlenirken hata oluştu ({ip}): {e}")


async def watch_log_and_analyze(log_path: str, engine: IPIntelFusion,
                                auto_block: bool = False,
                                notify_webhook: Optional[str] = None):
    print(f"[*] {log_path} canlı izleniyor... (Çıkmak için Ctrl+C)")
    async with httpx.AsyncClient() as client:
        try:
            with open(log_path, "r", encoding="utf-8", errors="ignore") as f:
                f.seek(0, 2)
                while True:
                    line = await asyncio.to_thread(f.readline)
                    if line:
                        ips = IP_REGEX.findall(line)
                        for ip in ips:
                            if validate_ip(ip):
                                asyncio.create_task(
                                    process_ip_safely(engine, client, ip, auto_block, notify_webhook)
                                )
                    else:
                        await asyncio.sleep(0.1)
        except FileNotFoundError:
            print(f"[!] Log dosyası bulunamadı: {log_path}")
        except KeyboardInterrupt:
            print("\n[!] İzleme kullanıcı tarafından durduruldu.")
        except Exception as e:
            print(f"[!] İzleme modunda beklenmeyen hata: {e}")


async def api_analyze(request):
    data = await request.json()
    ip = data.get("ip", "").strip()
    if not ip:
        return web.json_response({"error": "IP gerekli"}, status=400)
    engine = request.app["engine"]
    history = request.app["history"]
    async with httpx.AsyncClient() as client:
        result = await engine.analyze(client, ip)
    history.add(result)
    return web.json_response(result)

async def api_history(request):
    history = request.app["history"]
    search = request.query.get("search")
    limit = int(request.query.get("limit", 50))
    offset = int(request.query.get("offset", 0))
    entries = history.get_all(limit=limit, offset=offset, search=search)
    return web.json_response(entries)

async def api_stats(request):
    history = request.app["history"]
    stats = history.stats()
    stats["risk_distribution"] = history.risk_distribution()
    return web.json_response(stats)

async def api_settings_get(request):
    settings = request.app["settings"]
    return web.json_response(settings.data)

async def api_settings_post(request):
    settings = request.app["settings"]
    data = await request.json()
    for key, value in data.items():
        if key in settings.data:
            settings.set(key, value)
    request.app["engine"].update_keys()
    return web.json_response({"status": "ok"})

async def start_web_server(engine, history, settings, host="127.0.0.1", port=3030):
    app = web.Application()
    app["engine"] = engine
    app["history"] = history
    app["settings"] = settings

    web_dir = Path(__file__).parent / "web"
    app.router.add_static("/static", web_dir)

    app.router.add_post("/api/analyze", api_analyze)
    app.router.add_get("/api/history", api_history)
    app.router.add_get("/api/stats", api_stats)
    app.router.add_get("/api/settings", api_settings_get)
    app.router.add_post("/api/settings", api_settings_post)

    app.router.add_get("/", lambda r: web.FileResponse(web_dir / "index.html"))

    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, host, port)
    print(f"[*] Web arayüzü başlatıldı: http://{host}:{port}")
    await site.start()
    try:
        while True:
            await asyncio.sleep(3600)
    except asyncio.CancelledError:
        pass
    finally:
        await runner.cleanup()


async def main():
    parser = argparse.ArgumentParser(description="SZR-IP: Gelişmiş Asenkron IP İstihbarat & Savunma Sistemi")
    parser.add_argument("targets", nargs="*", help="Taranacak IP adresleri")
    parser.add_argument("-f", "--file", help="IP listesi içeren dosya")
    parser.add_argument("-o", "--output", help="Sonuçların yazılacağı dosya")
    parser.add_argument("--format", choices=["json", "csv"], default="json", help="Çıktı formatı")
    parser.add_argument("--abuseipdb-key", help="AbuseIPDB API anahtarı")
    parser.add_argument("--virustotal-key", help="VirusTotal API anahtarı")
    parser.add_argument("--shodan-key", help="Shodan API anahtarı")
    parser.add_argument("--maxmind-city", help="GeoLite2-City.mmdb dosya yolu")
    parser.add_argument("--maxmind-asn", help="GeoLite2-ASN.mmdb dosya yolu")
    parser.add_argument("--blacklist", help="Kara liste dosyası")
    parser.add_argument("--auto-block", action="store_true", help="Yüksek riskli IP'leri otomatik iptables ile engelle (root gerekir)")
    parser.add_argument("--slack-webhook", help="Yüksek risk bildirimleri için Slack Webhook URL")
    parser.add_argument("--watch-log", help="Canlı izlenecek log dosyası (ör. /var/log/nginx/access.log)")
    parser.add_argument("--web", action="store_true", help="Web arayüzünü başlat (127.0.0.1:3030)")

    args = parser.parse_args()

    print("""
   ███████╗███████╗██████╗     ██╗██████╗
   ██╔════╝╚════██║██╔══██╗    ██║██╔══██╗
   ███████╗    ██╔╝██████╔╝    ██║██████╔╝
   ╚════██║   ██╔╝ ██╔══██╗    ██║██╔═══╝
   ███████║   ██║  ██║  ██║    ██║██║
   ╚══════╝   ╚═╝  ╚═╝  ╚═╝    ╚═╝╚═╝
   Gelişmiş Asenkron IP İstihbarat & Savunma Sistemi
   SZR - Security Zone Recon
    """)

    settings = Settings()
    if args.abuseipdb_key:
        settings.set("abuseipdb_key", args.abuseipdb_key)
    if args.virustotal_key:
        settings.set("virustotal_key", args.virustotal_key)
    if args.shodan_key:
        settings.set("shodan_key", args.shodan_key)
    if args.slack_webhook:
        settings.set("slack_webhook", args.slack_webhook)
    if args.auto_block:
        settings.set("auto_block", True)

    history = HistoryManager()
    engine = IPIntelFusion(settings)

    if args.web:
        await start_web_server(engine, history, settings)
        return

    if args.watch_log:
        await watch_log_and_analyze(args.watch_log, engine,
                                    auto_block=settings.get("auto_block"),
                                    notify_webhook=settings.get("slack_webhook"))
        return

    ips = args.targets if args.targets else []
    if args.file:
        with open(args.file, "r") as f:
            ips.extend([line.strip() for line in f if line.strip()])

    if not ips:
        print("Hata: Hedef IP belirtilmedi veya dosya boş.")
        return

    print(f"[*] {len(ips)} IP taranıyor...")
    results = await engine.bulk_analyze(ips,
                                        auto_block=settings.get("auto_block"),
                                        notify_webhook=settings.get("slack_webhook"))
    for r in results:
        history.add(r)

    def export_results(results, format, output_file):
        if format == "json":
            output = json.dumps(results, indent=2, ensure_ascii=False)
        elif format == "csv":
            if not results:
                return
            flattened = []
            for r in results:
                flat = {}
                for k, v in r.items():
                    if isinstance(v, dict):
                        for k2, v2 in v.items():
                            flat[f"{k}_{k2}"] = v2
                    elif isinstance(v, list):
                        flat[k] = ",".join(map(str, v)) if v else ""
                    else:
                        flat[k] = v
                flattened.append(flat)
            output_buffer = io.StringIO()
            writer = csv.DictWriter(output_buffer, fieldnames=flattened[0].keys())
            writer.writeheader()
            writer.writerows(flattened)
            output = output_buffer.getvalue()
        else:
            raise ValueError("Format json veya csv olmalı")
        if output_file:
            with open(output_file, "w", encoding="utf-8") as f:
                f.write(output)
        else:
            print(output)

    export_results(results, args.format, args.output)
    print("[+] İşlem tamamlandı.")


if __name__ == "__main__":
    if sys.platform == "win32":
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    asyncio.run(main())